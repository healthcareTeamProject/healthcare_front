module.exports = require("./data/native-modules.json");
